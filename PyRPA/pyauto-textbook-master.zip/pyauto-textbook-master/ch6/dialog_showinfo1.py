# tkinter 불러오기 --- (1)
import tkinter.messagebox as mb

# 메시지 표시 --- (2)
mb.showinfo("격언", "두 번 일어난 일은 세 번도 일어난다")
