# outlook 계정 정보
account = 'example@outlook.kr'
password = '8B8JTMdnO3my'

