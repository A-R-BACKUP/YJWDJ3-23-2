# Gmail 계정 정보
account = 'example@gmail.com'
password = '16자리 코드'
