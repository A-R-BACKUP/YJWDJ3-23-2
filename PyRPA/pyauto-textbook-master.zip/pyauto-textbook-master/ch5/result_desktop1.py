import os
desktop_dir = os.path.expanduser('~/Desktop')
print(desktop_dir)
