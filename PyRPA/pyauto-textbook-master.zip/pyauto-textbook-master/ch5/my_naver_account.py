# Naver 계정 정보
account = 'example@naver.com'
password = 'KjMYfFopY!e3Y84If'
