msg = '출력할 메시지를 입력해주세요'
print(msg)
instr = input()
print('입력 내용:',instr)
