import tkinter as tk
from tkinter import messagebox as mb

# tkinter 창 숨기기
tk.Tk().withdraw()

# 메시지 표시
mb.showinfo("프로그램 실행", "check.py 파일이 실행되었습니다.")

quit()
