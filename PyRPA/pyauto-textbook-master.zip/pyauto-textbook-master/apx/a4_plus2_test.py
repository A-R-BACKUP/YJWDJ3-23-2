# 모듈 불러오기
import a4_plus2 as f

# 모듈 내의 함수 이용하기
print(f.plus(2, 6)) # 결과→ 8
print(f.plus(100,5)) # 결과→ 105


