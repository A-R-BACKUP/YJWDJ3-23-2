# 리스트 요소 만큼 반복 --- (*A)
a_list = [0,1,2]
for i in a_list:
    print(i)
# 결과→ 0 \n 1 \n 2

# 레인지 함수를 사용하여 반복 --- (*B)
for i in range(3):
    print(i)
# 결과→ 0 \n 1 \n 2

