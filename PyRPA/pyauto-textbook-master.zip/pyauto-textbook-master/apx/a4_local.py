# 인자에 2를 곱하는 함수
def two_mul(n):
    x = 2
    return x * n

x = 200
print(two_mul(5)) # 결과→ 10
print(x) # 결과→ 200
