# 인자 a와 b를 더하는 함수
def plus(a, b):
    return a + b

if __name__ == '__main__':
    # 함수 테스트
    print( plus(3, 5) ) # 결과→ 8
    print( plus(30, 25) ) # 결과→ 55
