apple = 210
banana = 140
price = apple * 3 + banana * 5
print(price) # 결과→ 1330

