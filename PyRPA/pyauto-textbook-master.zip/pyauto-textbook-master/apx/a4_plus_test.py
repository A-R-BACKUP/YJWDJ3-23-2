# 모듈 불러오기
import a4_plus as f

# 모듈 내의 함수 이용하기
print(f.plus(2, 3))

# 결과→
# 8
# 55
# 5

