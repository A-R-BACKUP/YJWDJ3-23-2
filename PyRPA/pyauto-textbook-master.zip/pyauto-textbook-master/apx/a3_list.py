# 리스트 초기화
a_list = [0, 1, 2]

# 값 변
a_list[2] = 22

# 값 참조
print( a_list[2] ) # 결과→22
