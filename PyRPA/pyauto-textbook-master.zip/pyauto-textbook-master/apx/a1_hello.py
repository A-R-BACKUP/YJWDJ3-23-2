print("Hello, Python!")

