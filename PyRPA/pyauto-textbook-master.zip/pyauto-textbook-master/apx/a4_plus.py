# 인자 a와 b를 더하는 함수
def plus(a, b):
    return a + b

# 함수 호출
print( plus(3, 5) ) # 결과→ 8
print( plus(30, 25) ) # 결과→ 55
